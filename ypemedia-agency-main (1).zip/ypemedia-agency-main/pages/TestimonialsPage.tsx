
import React from 'react';
import GlassCard from '../components/GlassCard';
import { Star, Quotes } from '@phosphor-icons/react';

const TestimonialsPage: React.FC = () => {
  const testimonials = [
    { 
        name: "Dr. Ankit Sharma", 
        location: "Dentist, India", 
        text: "The website redesign and AI receptionist have completely changed our front desk operations. Missed calls are down to zero.", 
        rating: 5,
        img: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=150&h=150"
    },
    { 
        name: "Emma Brown", 
        location: "Real Estate, Australia", 
        text: "The AI agent qualified over 40 leads while I was out on viewings. It's like having a full-time assistant for a fraction of the cost.", 
        rating: 5,
        img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150&h=150"
    },
    { 
        name: "Michael Lee", 
        location: "Consultant, USA", 
        text: "Professional, fast, and results-oriented. The cold email infrastructure they built is top-tier and actually delivers meetings.", 
        rating: 5,
        img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150&h=150"
    },
    { 
        name: "Rohit Verma", 
        location: "Agency Owner, India", 
        text: "Their web design expertise is evident. The conversion flow is smooth and our clients love the new interface.", 
        rating: 5,
        img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150&h=150"
    },
    { 
        name: "David Wilson", 
        location: "SaaS Sales, UK", 
        text: "The outbound system is elite. No robotic templates – just high-conversion, personalized outreach that works.", 
        rating: 5,
        img: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?auto=format&fit=crop&q=80&w=150&h=150"
    },
    { 
        name: "Ayesha Khan", 
        location: "Startup Founder, India", 
        text: "Clean aesthetics and smart automation. YPE Media helped us scale our initial user acquisition effortlessly.", 
        rating: 5,
        img: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150&h=150"
    },
  ];

  return (
    <div className="pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-black mb-6">Trusted Locally, Scaling Globally</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Actual results from real business owners using our AI-driven systems.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <GlassCard key={idx} className="flex flex-col">
              <div className="flex justify-between items-start mb-6">
                <div className="flex text-yellow-500">
                  {[...Array(t.rating)].map((_, i) => <Star key={i} weight="fill" size={16} />)}
                </div>
                <Quotes size={32} className="text-white/10" weight="fill" />
              </div>
              <p className="text-gray-300 italic mb-8 flex-grow leading-relaxed">
                “{t.text}”
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full border border-white/20 overflow-hidden mr-4">
                  <img src={t.img} alt={t.name} className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500" />
                </div>
                <div>
                  <div className="font-bold text-white">{t.name}</div>
                  <div className="text-xs text-purple-400 uppercase tracking-widest">{t.location}</div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TestimonialsPage;
