
import React from 'react';
import GlassCard from '../components/GlassCard';
import GlowButton from '../components/GlowButton';
import { Link } from 'react-router-dom';
import { Check, DeviceMobile, Lightning, MagnifyingGlass, Gear, Headset, Robot, Sparkle, ChatCircleDots } from '@phosphor-icons/react';

const Services: React.FC = () => {
  const calendlyLink = "https://calendly.com/ypemedia-in/new-meeting";

  return (
    <div className="pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h1 className="text-4xl md:text-6xl font-black mb-6">Digital Scaling Systems</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            We don't just build sites; we build autonomous client acquisition engines.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {/* AI Receptionist */}
          <GlassCard className="flex flex-col border-purple-500/20 bg-purple-950/10 h-full p-10">
            <div className="p-4 bg-purple-600/20 rounded-2xl text-purple-400 w-fit mb-8">
              <Headset size={48} weight="duotone" />
            </div>
            <h2 className="text-3xl font-bold mb-6">AI Receptionist (Inbound/Outbound)</h2>
            <p className="text-gray-300 mb-8 text-lg leading-relaxed flex-grow">
              An autonomous voice AI that handles your phone lines 24/7. It can book appointments, answer common FAQs, and even perform outbound follow-ups with human-like natural conversation.
            </p>
            <ul className="space-y-3 mb-10 text-gray-400">
              <li className="flex items-center"><Check className="mr-2 text-purple-500" /> 24/7 Inbound Support</li>
              <li className="flex items-center"><Check className="mr-2 text-purple-500" /> Real-time Appointment Booking</li>
              <li className="flex items-center"><Check className="mr-2 text-purple-500" /> Outbound Lead Nurturing</li>
              <li className="flex items-center"><Check className="mr-2 text-purple-500" /> CRM Syncing & Logging</li>
            </ul>
            <a href={calendlyLink} target="_blank" rel="noopener noreferrer">
                <GlowButton className="w-full">Book AI Demo</GlowButton>
            </a>
          </GlassCard>

          {/* AI Agent */}
          <GlassCard className="flex flex-col border-blue-500/20 bg-blue-950/10 h-full p-10">
            <div className="p-4 bg-blue-600/20 rounded-2xl text-blue-400 w-fit mb-8">
              <Robot size={48} weight="duotone" />
            </div>
            <h2 className="text-3xl font-bold mb-6">AI Growth Agent</h2>
            <p className="text-gray-300 mb-8 text-lg leading-relaxed flex-grow">
              Your autonomous backend employee. These agents manage your LinkedIn outreach, Instagram DMs, and basic customer support inquiries while you focus on high-level strategy.
            </p>
            <ul className="space-y-3 mb-10 text-gray-400">
              <li className="flex items-center"><Check className="mr-2 text-blue-500" /> Multi-channel Outreach</li>
              <li className="flex items-center"><Check className="mr-2 text-blue-500" /> Lead Qualification & Scoring</li>
              <li className="flex items-center"><Check className="mr-2 text-blue-500" /> Content & Copy Drafting</li>
              <li className="flex items-center"><Check className="mr-2 text-blue-500" /> Automated Research</li>
            </ul>
            <a href={calendlyLink} target="_blank" rel="noopener noreferrer">
                <GlowButton variant="secondary" className="w-full bg-blue-600 hover:bg-blue-700">Deploy AI Agent</GlowButton>
            </a>
          </GlassCard>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Web Design Service */}
          <GlassCard className="p-10">
            <div className="p-3 bg-white/5 rounded-xl text-gray-300 w-fit mb-6">
              <Lightning size={32} />
            </div>
            <h2 className="text-2xl font-bold mb-4">Web Design & Funnels</h2>
            <p className="text-gray-400 mb-8">
              High-performance landing pages for dentists and real estate professionals. Built to load fast and convert high.
            </p>
            <ul className="space-y-2 mb-8 text-sm text-gray-500">
              <li className="flex items-center"><Check className="mr-2" /> Mobile-Responsive Design</li>
              <li className="flex items-center"><Check className="mr-2" /> SEO Architecture</li>
              <li className="flex items-center"><Check className="mr-2" /> Speed Optimization</li>
            </ul>
            <Link to="/contact" className="text-purple-400 font-bold hover:underline">Get a Website Quote &rarr;</Link>
          </GlassCard>

          {/* Cold Email Service */}
          <GlassCard className="p-10">
            <div className="p-3 bg-white/5 rounded-xl text-gray-300 w-fit mb-6">
              <Sparkle size={32} />
            </div>
            <h2 className="text-2xl font-bold mb-4">Cold Email Systems</h2>
            <p className="text-gray-400 mb-8">
              Scientific outbound systems that bypass spam filters and land in the primary inbox of your ideal clients.
            </p>
            <ul className="space-y-2 mb-8 text-sm text-gray-500">
              <li className="flex items-center"><Check className="mr-2" /> ICP Lead Scraping</li>
              <li className="flex items-center"><Check className="mr-2" /> Direct-Response Copy</li>
              <li className="flex items-center"><Check className="mr-2" /> Domain Warming & Infrastructure</li>
            </ul>
            <Link to="/contact" className="text-blue-400 font-bold hover:underline">Start Outreach &rarr;</Link>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};

export default Services;
