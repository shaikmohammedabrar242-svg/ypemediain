
import React from 'react';
import { Link } from 'react-router-dom';
import { Rocket, Envelope, Money, Globe, CheckCircle, Star, ArrowRight, Robot, Headset, Sparkle } from '@phosphor-icons/react';
import GlassCard from '../components/GlassCard';
import GlowButton from '../components/GlowButton';

const Home: React.FC = () => {
  const calendlyLink = "https://calendly.com/ypemedia-in/new-meeting";

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-purple-900/30 border border-purple-500/30 text-purple-300 text-xs font-bold mb-8 animate-fade-in uppercase tracking-widest">
            <span>AI-Powered Client Acquisition</span>
          </div>
          <h1 className="text-5xl lg:text-7xl font-extrabold tracking-tight mb-8 leading-tight">
            High-Converting Websites & <br className="hidden md:block" /> 
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-indigo-400 to-blue-400">
              AI-Driven Outreach
            </span>
          </h1>
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-gray-400 mb-10 leading-relaxed">
            We help dentists, real estate agents, and modern firms dominate their markets with stunning websites and autonomous AI receptionist systems.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <a href={calendlyLink} target="_blank" rel="noopener noreferrer">
              <GlowButton>Book a Free Strategy Call</GlowButton>
            </a>
            <Link to="/services">
              <GlowButton variant="secondary">Explore AI Solutions</GlowButton>
            </Link>
          </div>
          <div className="mt-12 text-gray-500 font-medium">
            👉 Serving <span className="text-gray-300">India, USA, UK & Australia</span>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-20 bg-black/40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-4">Why Businesses Choose YPE Media</h2>
            <div className="w-20 h-1 bg-purple-600 mx-auto rounded-full"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <GlassCard className="flex flex-col items-start space-y-4 group">
              <div className="p-3 rounded-xl bg-purple-600/20 text-purple-400 group-hover:scale-110 transition-transform">
                <Rocket size={32} weight="light" />
              </div>
              <h3 className="text-xl font-bold">Conversion-First</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                We design lead-generating machines that turn cold traffic into active patient or client inquiries.
              </p>
            </GlassCard>

            <GlassCard className="flex flex-col items-start space-y-4 group">
              <div className="p-3 rounded-xl bg-blue-600/20 text-blue-400 group-hover:scale-110 transition-transform">
                <Robot size={32} weight="light" />
              </div>
              <h3 className="text-xl font-bold">Autonomous AI</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                AI agents and receptionists that handle your inbound and outbound calls 24/7 without a coffee break.
              </p>
            </GlassCard>

            <GlassCard className="flex flex-col items-start space-y-4 group">
              <div className="p-3 rounded-xl bg-green-600/20 text-green-400 group-hover:scale-110 transition-transform">
                <Money size={32} weight="light" />
              </div>
              <h3 className="text-xl font-bold">High ROI Velocity</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Our systems are built to pay for themselves within the first few months by filling your pipeline.
              </p>
            </GlassCard>

            <GlassCard className="flex flex-col items-start space-y-4 group">
              <div className="p-3 rounded-xl bg-indigo-600/20 text-indigo-400 group-hover:scale-110 transition-transform">
                <Globe size={32} weight="light" />
              </div>
              <h3 className="text-xl font-bold">Global Presence</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                We bridge the gap between India's talent and global business standards across 4 major markets.
              </p>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 space-y-6 md:space-y-0">
            <div>
              <h2 className="text-3xl lg:text-5xl font-bold mb-4">Our Core Systems</h2>
              <p className="text-gray-400 max-w-lg">Advanced technology stack to automate your growth.</p>
            </div>
            <Link to="/services" className="text-purple-400 font-bold flex items-center hover:text-purple-300 transition-colors">
              Explore All Services <ArrowRight className="ml-2" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <GlassCard className="p-8 border-purple-500/20 bg-purple-900/10">
              <div className="flex items-center space-x-4 mb-6">
                <div className="p-4 bg-purple-600/20 rounded-2xl text-purple-400">
                  <Headset size={40} weight="duotone" />
                </div>
                <h3 className="text-2xl font-bold">AI Receptionist</h3>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                24/7 autonomous voice system for inbound inquiries and outbound follow-ups. Never miss a lead again.
              </p>
              <Link to="/services" className="text-purple-400 font-bold flex items-center group">
                Learn more <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
            </GlassCard>

            <GlassCard className="p-8 border-blue-500/20 bg-blue-900/10">
              <div className="flex items-center space-x-4 mb-6">
                <div className="p-4 bg-blue-600/20 rounded-2xl text-blue-400">
                  <Sparkle size={40} weight="duotone" />
                </div>
                <h3 className="text-2xl font-bold">AI Growth Agent</h3>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Intelligent agents that manage your CRM, social DMs, and basic customer support automatically.
              </p>
              <Link to="/services" className="text-blue-400 font-bold flex items-center group">
                Learn more <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Testimonials Snippet */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl lg:text-5xl font-bold text-center mb-16">Client Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <GlassCard className="relative pt-12">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full border-4 border-[#030303] overflow-hidden">
                <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=150&h=150" alt="Rahul" className="w-full h-full object-cover" />
              </div>
              <div className="flex justify-center mb-4 text-yellow-500">
                {[...Array(5)].map((_, i) => <Star key={i} weight="fill" size={18} />)}
              </div>
              <p className="text-gray-300 italic mb-6 text-center leading-relaxed">
                “YPE Media redesigned our website and inquiries doubled within 30 days. Their AI systems are light-years ahead.”
              </p>
              <div className="text-center">
                <div className="font-bold">Dr. Rahul Mehta</div>
                <div className="text-xs text-purple-400 uppercase tracking-widest font-bold">Dentist, India</div>
              </div>
            </GlassCard>

            <GlassCard className="relative pt-12">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full border-4 border-[#030303] overflow-hidden">
                <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150&h=150" alt="James" className="w-full h-full object-cover" />
              </div>
              <div className="flex justify-center mb-4 text-yellow-500">
                {[...Array(5)].map((_, i) => <Star key={i} weight="fill" size={18} />)}
              </div>
              <p className="text-gray-300 italic mb-6 text-center leading-relaxed">
                “The AI receptionist system booked me 14 meetings in the first month. No more missed calls while I'm on site.”
              </p>
              <div className="text-center">
                <div className="font-bold">James Carter</div>
                <div className="text-xs text-purple-400 uppercase tracking-widest font-bold">Real Estate, UK</div>
              </div>
            </GlassCard>

            <GlassCard className="relative pt-12">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full border-4 border-[#030303] overflow-hidden">
                <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150&h=150" alt="Sarah" className="w-full h-full object-cover" />
              </div>
              <div className="flex justify-center mb-4 text-yellow-500">
                {[...Array(5)].map((_, i) => <Star key={i} weight="fill" size={18} />)}
              </div>
              <p className="text-gray-300 italic mb-6 text-center leading-relaxed">
                “Professional execution and true AI integration. They actually deliver high-intent leads consistently.”
              </p>
              <div className="text-center">
                <div className="font-bold">Sarah Williams</div>
                <div className="text-xs text-purple-400 uppercase tracking-widest font-bold">Consultancy Founder, USA</div>
              </div>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4">
          <GlassCard className="text-center bg-gradient-to-br from-purple-900/40 to-blue-900/40 p-12 lg:p-20 relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-3xl lg:text-5xl font-black mb-6">Ready to Automate Your Growth?</h2>
              <p className="text-xl text-gray-300 mb-10">Book a free AI strategy audit today. Limited availability for custom systems.</p>
              <a href={calendlyLink} target="_blank" rel="noopener noreferrer">
                <GlowButton className="text-lg">Schedule Discovery Call</GlowButton>
              </a>
            </div>
            <div className="absolute top-0 right-0 p-8 text-white/5 transform translate-x-1/4 -translate-y-1/4 scale-150">
                <Robot size={200} weight="thin" />
            </div>
          </GlassCard>
        </div>
      </section>
    </div>
  );
};

export default Home;
