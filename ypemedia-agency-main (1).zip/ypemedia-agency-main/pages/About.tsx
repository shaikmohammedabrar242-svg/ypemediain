
import React from 'react';
import GlassCard from '../components/GlassCard';
import { Target, Lightbulb, UsersThree, ChartLineUp } from '@phosphor-icons/react';

const About: React.FC = () => {
  return (
    <div className="pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-black mb-6">Our Story</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Small and mid-sized businesses deserve high-quality digital systems without overpaying agencies.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">How it all started</h2>
            <p className="text-gray-400 leading-relaxed text-lg">
              YPE Media was founded with one simple belief: great services deserve great digital presence. 
              After working with multiple service businesses, we saw the same problem repeatedly—excellent services, but poor websites and no predictable lead flow.
            </p>
            <p className="text-gray-400 leading-relaxed text-lg font-medium text-white">
              So we fixed it. We combined expert web design with the science of outbound systems.
            </p>
          </div>
          <img src="https://picsum.photos/seed/office/800/500" alt="About YPE" className="rounded-3xl border border-white/10 shadow-2xl" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          <GlassCard className="text-center">
            <div className="w-16 h-16 bg-purple-600/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-purple-400">
              <Target size={32} />
            </div>
            <h3 className="text-xl font-bold mb-3">Our Mission</h3>
            <p className="text-gray-400">To help businesses grow with conversion-focused websites and ethical, personalized cold email outreach.</p>
          </GlassCard>
          
          <GlassCard className="text-center">
            <div className="w-16 h-16 bg-blue-600/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-blue-400">
              <Lightbulb size={32} />
            </div>
            <h3 className="text-xl font-bold mb-3">Our Values</h3>
            <p className="text-gray-400">Transparency over hype. Results over promises. Long-term relationships over short-term transactions.</p>
          </GlassCard>

          <GlassCard className="text-center">
            <div className="w-16 h-16 bg-indigo-600/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-indigo-400">
              <UsersThree size={32} />
            </div>
            <h3 className="text-xl font-bold mb-3">Our Team</h3>
            <p className="text-gray-400">A lean, skilled team focused on execution—not fluff. Led by experienced growth strategists.</p>
          </GlassCard>
        </div>

        <div className="bg-white/5 rounded-3xl p-10 md:p-16 border border-white/10">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-2">Milestones</h2>
            <div className="w-16 h-1 bg-purple-500 mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div>
              <div className="text-5xl font-black mb-2 text-purple-500">1.5+</div>
              <div className="text-lg font-bold">Years of Operation</div>
            </div>
            <div>
              <div className="text-5xl font-black mb-2 text-purple-500">4+</div>
              <div className="text-lg font-bold">Countries with Active Clients</div>
            </div>
            <div>
              <div className="text-5xl font-black mb-2 text-purple-500">50+</div>
              <div className="text-lg font-bold">Systems Built & Optimized</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
