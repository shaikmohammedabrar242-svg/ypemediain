
import React, { useState } from 'react';
import GlassCard from '../components/GlassCard';
import GlowButton from '../components/GlowButton';
import { Envelope, MapPin, Clock, Globe } from '@phosphor-icons/react';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-black mb-6">Get in Touch</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Ready to scale your business? Let's talk strategy.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Info Side */}
          <div className="lg:col-span-1 space-y-8">
            <h3 className="text-2xl font-bold mb-6">Contact Details</h3>
            
            <div className="flex items-start">
              <div className="p-3 bg-purple-600/20 text-purple-400 rounded-xl mr-4"><Envelope size={24} /></div>
              <div>
                <div className="font-bold">Email Us</div>
                <a href="mailto:contact@ypemedia.in" className="text-gray-400 hover:text-purple-400">contact@ypemedia.in</a>
              </div>
            </div>

            <div className="flex items-start">
              <div className="p-3 bg-blue-600/20 text-blue-400 rounded-xl mr-4"><Globe size={24} /></div>
              <div>
                <div className="font-bold">Website</div>
                <a href="https://ypemedia.in" className="text-gray-400 hover:text-blue-400">ypemedia.in</a>
              </div>
            </div>

            <div className="flex items-start">
              <div className="p-3 bg-indigo-600/20 text-indigo-400 rounded-xl mr-4"><Clock size={24} /></div>
              <div>
                <div className="font-bold">Business Hours</div>
                <div className="text-gray-400">Mon – Sat: 10:00 AM – 7:00 PM (IST)</div>
              </div>
            </div>

            <div className="flex items-start">
              <div className="p-3 bg-green-600/20 text-green-400 rounded-xl mr-4"><MapPin size={24} /></div>
              <div>
                <div className="font-bold">Location</div>
                <div className="text-gray-400">India (Serving Global Clients)</div>
              </div>
            </div>

            <GlassCard className="mt-12 bg-purple-900/10 border-purple-500/20">
              <h4 className="font-bold mb-2">Fast Response</h4>
              <p className="text-sm text-gray-400 leading-relaxed">We typically respond to all inquiries within 24 business hours.</p>
            </GlassCard>
          </div>

          {/* Form Side */}
          <div className="lg:col-span-2">
            <GlassCard className="p-8 md:p-12">
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-300">Your Name</label>
                      <input 
                        type="text" 
                        required
                        placeholder="John Doe"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-300">Work Email</label>
                      <input 
                        type="email" 
                        required
                        placeholder="john@company.com"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-300">Company Name</label>
                      <input 
                        type="text" 
                        placeholder="Company Ltd."
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-300">Interested In</label>
                      <select 
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors text-gray-400"
                      >
                        <option value="web-design">Web Design Services</option>
                        <option value="cold-email">Cold Email Outreach</option>
                        <option value="both">Both Systems</option>
                        <option value="other">Other Inquiry</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Message</label>
                    <textarea 
                      rows={4}
                      placeholder="Tell us about your project..."
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors"
                    ></textarea>
                  </div>

                  <GlowButton className="w-full md:w-auto px-12">Send Inquiry</GlowButton>
                </form>
              ) : (
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle size={48} weight="fill" />
                  </div>
                  <h3 className="text-3xl font-bold mb-4">Message Sent!</h3>
                  <p className="text-gray-400 mb-8">Thank you for reaching out. A growth strategist will be in touch with you shortly.</p>
                  <GlowButton variant="secondary" onClick={() => setSubmitted(false)}>Send Another Message</GlowButton>
                </div>
              )}
            </GlassCard>
          </div>
        </div>
      </div>
    </div>
  );
};

const CheckCircle = ({ size, weight }: { size: number, weight: "fill" | "light" | "regular" }) => (
    <svg width={size} height={size} viewBox="0 0 256 256" fill="currentColor">
        <path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm45.66,85.66-56,56a8,8,0,0,1-11.32,0l-24-24a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35a8,8,0,0,1,11.32,11.32Z" />
    </svg>
)

export default Contact;
