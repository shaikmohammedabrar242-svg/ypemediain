
import React from 'react';
import { Link } from 'react-router-dom';
import { InstagramLogo, LinkedinLogo, TwitterLogo, Globe } from '@phosphor-icons/react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-white/5 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link to="/" className="text-2xl font-black tracking-tighter">
              YPE<span className="text-purple-500">MEDIA</span>
            </Link>
            <p className="text-gray-400 leading-relaxed max-w-xs">
              Building the digital infrastructure for modern service businesses. Specialized in web design, cold outreach, and cutting-edge AI automation.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://www.linkedin.com/in/sheikhabrar/" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-purple-600 transition-colors"
              >
                <LinkedinLogo size={20} />
              </a>
              <a 
                href="https://www.instagram.com/ypemedia.in?igsh=MWJjNWVzNTVlNzd4aw==" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-purple-600 transition-colors"
              >
                <InstagramLogo size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-purple-600 transition-colors">
                <TwitterLogo size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-white mb-6 uppercase text-sm tracking-widest">Solutions</h4>
            <ul className="space-y-4 text-gray-400">
              <li><Link to="/services" className="hover:text-purple-400 transition-colors">AI Receptionist</Link></li>
              <li><Link to="/services" className="hover:text-purple-400 transition-colors">AI Agents</Link></li>
              <li><Link to="/services" className="hover:text-purple-400 transition-colors">Web Design</Link></li>
              <li><Link to="/services" className="hover:text-purple-400 transition-colors">Cold Email Systems</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-6 uppercase text-sm tracking-widest">Company</h4>
            <ul className="space-y-4 text-gray-400">
              <li><Link to="/about" className="hover:text-purple-400 transition-colors">Our Story</Link></li>
              <li><Link to="/testimonials" className="hover:text-purple-400 transition-colors">Success Stories</Link></li>
              <li><Link to="/contact" className="hover:text-purple-400 transition-colors">Contact Us</Link></li>
              <li><a href="https://calendly.com/ypemedia-in/new-meeting" target="_blank" rel="noopener noreferrer" className="hover:text-purple-400 transition-colors">Book a Call</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-6 uppercase text-sm tracking-widest">Newsletter</h4>
            <p className="text-gray-400 mb-6 text-sm">Growth tips delivered to your inbox weekly.</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="email@example.com" 
                className="bg-white/5 border border-white/10 rounded-l-xl px-4 py-3 w-full focus:outline-none"
              />
              <button className="bg-purple-600 px-4 rounded-r-xl font-bold hover:bg-purple-700 transition-colors">Join</button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/5 pt-10 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
          <div>© 2024 YPE Media. All rights reserved.</div>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <div className="flex items-center">
              <Globe size={16} className="mr-1" />
              <span>India, USA, UK, Australia</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
