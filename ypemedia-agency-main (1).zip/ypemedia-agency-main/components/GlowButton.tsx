
import React from 'react';

interface GlowButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline';
}

const GlowButton: React.FC<GlowButtonProps> = ({ 
  children, 
  onClick, 
  className = "", 
  variant = 'primary' 
}) => {
  const baseStyles = "px-8 py-4 rounded-full font-bold transition-all duration-300 transform active:scale-95 text-center inline-block";
  
  const variants = {
    primary: "bg-purple-600 text-white shadow-[0_0_25px_rgba(147,51,234,0.4)] hover:shadow-[0_0_40px_rgba(147,51,234,0.7)] hover:bg-purple-500",
    secondary: "bg-white/10 text-white backdrop-blur-md hover:bg-white/20 border border-white/20",
    outline: "border border-purple-500/50 text-purple-400 hover:bg-purple-500/10"
  };

  return (
    <button onClick={onClick} className={`${baseStyles} ${variants[variant]} ${className}`}>
      {children}
    </button>
  );
};

export default GlowButton;
