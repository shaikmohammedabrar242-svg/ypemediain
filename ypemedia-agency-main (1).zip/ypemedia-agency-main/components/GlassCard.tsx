
import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
}

const GlassCard: React.FC<GlassCardProps> = ({ children, className = "" }) => {
  return (
    <div className={`backdrop-blur-lg bg-white/5 border border-white/10 rounded-2xl p-6 transition-all hover:bg-white/10 ${className}`}>
      {children}
    </div>
  );
};

export default GlassCard;
